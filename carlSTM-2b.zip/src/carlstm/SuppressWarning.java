package carlstm;

/**
 * Created by simonorlovsky on 1/29/16.
 */
public @interface SuppressWarning {
}
